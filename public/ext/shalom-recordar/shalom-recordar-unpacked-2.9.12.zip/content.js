(() => {
const CONTENT_STATE_KEY = '__shalomRecordarContentState__';
const DOC_INPUT_ID = 'inputnombre';
// Desplegable de tipo de documento junto al campo de busqueda. El usuario elige
// aqui el tipo real (DNI/RUC/CE/PS), asi que manda sobre la longitud: es la
// fuente fiable. Antes se clasificaba solo por la cantidad de digitos, lo que
// descartaba el pasaporte (PS, que admite letras) y confundia longitudes
// (un CE de 8 digitos se guardaba como DNI).
const TIPODOC_SELECT_ID = 'tipodoclist';
const DOC_TYPES = ['DNI', 'RUC', 'CE', 'PS'];
// Cantidad exacta de digitos por tipo. Solo se captura cuando el numero esta
// completo: nada de registros con el documento a medias. PS (pasaporte) es
// alfanumerico y de longitud variable, asi que no lleva un largo fijo.
const DOC_EXPECTED_LENGTH = { DNI: 8, CE: 9, RUC: 11 };
const OS_INPUT_ID = 'inputnroguia';
const OS_MIN_LENGTH = 8;
const OS_MAX_LENGTH = 9;
const CLAVE_FIELDS = ['swal-input1', 'swal-input2', 'swal-input3', 'swal-input4'];
// Senales de que la clave fue CORRECTA: el servidor solo inyecta estos
// formularios cuando el codigo validado es valido. El cierre del modal de
// validacion no sirve: tambien ocurre al cancelar o fallar.
//   - frmEntrega  (action .../entrega/ajax): registro de la entrega.
//   - formPagoOS  (action .../pagos/Generar): ventana "Comprobante".
const CONFIRMATION_FORMS = [
    { id: 'frmEntrega', actionHint: 'entrega/ajax' },
    { id: 'formPagoOS', actionHint: 'pagos/generar' },
];
const DEDUPE_WINDOW_MS = 1500;
const OS_DEBOUNCE_MS = 650;
// El documento (DNI/RUC/CE/PS) se captura tras una pausa al teclear, no en cada
// pulsacion: asi se guarda el numero completo una sola vez y no un registro por
// tecla. Mismo criterio que la OS.
const DOC_DEBOUNCE_MS = 650;

function getContentState() {
    const globalState = globalThis[CONTENT_STATE_KEY] || {};
    globalThis[CONTENT_STATE_KEY] = globalState;
    return globalState;
}

// El contexto de la extension se invalida al recargarla o actualizarla: el
// content script viejo sigue vivo en la pagina pero `chrome.runtime` pasa a ser
// undefined y cualquier sendMessage revienta. Se comprueba antes de usarlo y se
// desmonta todo para dejar de escuchar en una pagina ya huerfana.
function isExtensionContextValid() {
    try {
        return Boolean(globalThis.chrome && chrome.runtime && chrome.runtime.id);
    } catch {
        return false;
    }
}

function teardownCapture() {
    const state = getContentState();
    if (state.torndown) return;
    state.torndown = true;

    for (const key of Object.keys(state.osDebounceTimers || {})) {
        clearTimeout(state.osDebounceTimers[key]);
    }
    state.osDebounceTimers = {};
    for (const key of Object.keys(state.docDebounceTimers || {})) {
        clearTimeout(state.docDebounceTimers[key]);
    }
    state.docDebounceTimers = {};
    state.claveBuffer = {};

    if (state.captureObserver) {
        state.captureObserver.disconnect();
        state.captureObserver = null;
    }
    state.captureObserverAttached = false;

    if (state.documentListenerAttached) {
        document.removeEventListener('input', handleCapture, true);
        document.removeEventListener('change', handleCapture, true);
        document.removeEventListener('blur', handleCapture, true);
        state.documentListenerAttached = false;
    }
}

function normalizeText(rawValue) {
    return String(rawValue ?? '').trim();
}

function normalizeDigits(rawValue) {
    return normalizeText(rawValue).replace(/\s+/g, '');
}

function classifyDocumentValue(rawValue) {
    const value = normalizeDigits(rawValue);

    if (!/^\d+$/.test(value)) {
        return null;
    }

    if (value.length === 8) return { field: 'DNI', value };
    if (value.length === 9) return { field: 'CE', value };
    if (value.length === 11) return { field: 'RUC', value };
    return null;
}

function getInputSource(target) {
    const raw = String(target?.id || target?.name || target?.placeholder || target?.getAttribute?.('aria-label') || target?.tagName || 'sin_nombre');
    return raw.trim();
}

function getInputId(target) {
    return getInputSource(target).toLowerCase();
}

function getFieldValue(target) {
    if (!target) return '';
    if (typeof target.value === 'string') return target.value;
    if (typeof target.textContent === 'string') return target.textContent;
    return '';
}

function isCaptureTarget(target) {
    return Boolean(target) && (target.nodeType === 1 || typeof target.value === 'string' || typeof target.textContent === 'string');
}

function isClaveField(target) {
    return CLAVE_FIELDS.includes(getInputId(target));
}

function isOsField(target) {
    return getInputId(target) === OS_INPUT_ID;
}

function isDocumentField(target) {
    return getInputId(target) === DOC_INPUT_ID;
}

function isRelevantField(target) {
    return isClaveField(target) || isOsField(target) || isDocumentField(target);
}

function shouldCapture(event) {
    return Boolean(event)
        && !event.defaultPrevented
        && !event.isComposing
        && (event.type === 'input' || event.type === 'change');
}

function canSendCapture(state, dedupeKey, eventTimeStamp) {
    const now = typeof eventTimeStamp === 'number' && Number.isFinite(eventTimeStamp) ? eventTimeStamp : Date.now();
    const previous = state.lastCaptureByKey?.[dedupeKey];
    if (previous && now - previous < DEDUPE_WINDOW_MS) {
        return false;
    }

    state.lastCaptureByKey ||= {};
    state.lastCaptureByKey[dedupeKey] = now;
    return true;
}

function sendCapture(field, value, source, eventTimeStamp) {
    if (!isExtensionContextValid()) {
        teardownCapture();
        return;
    }

    const state = getContentState();
    const dedupeKey = [source, field, value].join('|');
    if (!canSendCapture(state, dedupeKey, eventTimeStamp)) {
        return;
    }

    const message = {
        action: 'saveData',
        data: {
            captureId: [source, field, value, String(eventTimeStamp ?? Date.now())].join('|'),
            field,
            value,
            source,
            timestamp: new Date().toISOString(),
        },
    };

    try {
        // El callback consume chrome.runtime.lastError: sin el, un service
        // worker dormido o sin receptor deja un error no capturado en consola.
        chrome.runtime.sendMessage(message, () => void chrome.runtime.lastError);
    } catch {
        // El contexto pudo invalidarse entre la comprobacion y el envio.
        teardownCapture();
    }
}

// Tipo elegido en el desplegable, o '' si no existe / no es uno conocido.
function getSelectedDocType() {
    const select = typeof document.getElementById === 'function' ? document.getElementById(TIPODOC_SELECT_ID) : null;
    const raw = select && typeof select.value === 'string' ? select.value.trim().toUpperCase() : '';
    return DOC_TYPES.includes(raw) ? raw : '';
}

// Clasifica segun el tipo elegido en el desplegable (manda sobre la longitud).
// El pasaporte (PS) admite alfanumerico; el resto exige solo digitos, pero sin
// imponer una longitud concreta: el usuario ya declaro el tipo.
function classifyByDocType(docType, rawValue) {
    if (docType === 'PS') {
        const value = normalizeText(rawValue).toUpperCase().replace(/\s+/g, '');
        return value ? { field: 'PS', value } : null;
    }
    const value = normalizeDigits(rawValue);
    if (!/^\d+$/.test(value)) return null;
    // El desplegable decide el tipo, pero solo se captura con la longitud
    // exacta: DNI 8, CE 9, RUC 11. Menos digitos = numero incompleto, se ignora.
    const expected = DOC_EXPECTED_LENGTH[docType];
    if (expected && value.length !== expected) return null;
    return { field: docType, value };
}

function captureDocument(target, source, eventTimeStamp) {
    const docType = getSelectedDocType();
    // El desplegable es la fuente fiable; la clasificacion por longitud queda de
    // respaldo cuando el desplegable no esta disponible (p. ej. en las pruebas).
    const classified = docType
        ? classifyByDocType(docType, getFieldValue(target))
        : classifyDocumentValue(getFieldValue(target));
    if (!classified) return;
    sendCapture(classified.field, classified.value, source, eventTimeStamp);
}

function getDocDebounceKey(source) {
    return ['doc', source].join('|');
}

function clearDocDebounce(state, source) {
    const key = getDocDebounceKey(source);
    const timer = state.docDebounceTimers?.[key];
    if (timer) {
        clearTimeout(timer);
        delete state.docDebounceTimers[key];
    }
}

function saveDocFinalValue(target, source, eventTimeStamp) {
    const state = getContentState();
    clearDocDebounce(state, source);
    captureDocument(target, source, eventTimeStamp);
}

function scheduleDocDebouncedSave(target, source, eventTimeStamp) {
    const state = getContentState();
    state.docDebounceTimers ||= {};
    const key = getDocDebounceKey(source);

    clearDocDebounce(state, source);
    state.docDebounceTimers[key] = setTimeout(() => {
        delete state.docDebounceTimers[key];
        saveDocFinalValue(target, source, eventTimeStamp);
    }, DOC_DEBOUNCE_MS);
}

function captureOs(target, source, eventTimeStamp) {
    const value = normalizeText(getFieldValue(target));
    // La OS completa puede tener 8 o 9 digitos; menos = numero a medias.
    if (!/^\d+$/.test(value) || value.length < OS_MIN_LENGTH || value.length > OS_MAX_LENGTH) return null;
    sendCapture('OS', value, source, eventTimeStamp);
    return value;
}

function getOsDebounceKey(source) {
    return ['os', source].join('|');
}

function clearOsDebounce(state, source) {
    const key = getOsDebounceKey(source);
    const timer = state.osDebounceTimers?.[key];
    if (timer) {
        clearTimeout(timer);
        delete state.osDebounceTimers[key];
    }
}

function saveOsFinalValue(target, source, eventTimeStamp) {
    const state = getContentState();
    const value = captureOs(target, source, eventTimeStamp);
    if (!value) {
        clearOsDebounce(state, source);
        return;
    }

    clearOsDebounce(state, source);
}

function scheduleOsDebouncedSave(target, source, eventTimeStamp) {
    const state = getContentState();
    state.osDebounceTimers ||= {};
    const key = getOsDebounceKey(source);

    clearOsDebounce(state, source);
    state.osDebounceTimers[key] = setTimeout(() => {
        delete state.osDebounceTimers[key];
        saveOsFinalValue(target, source, eventTimeStamp);
    }, OS_DEBOUNCE_MS);
}

function captureClave(target) {
    const state = getContentState();
    state.claveBuffer ||= {};
    // Se indexa por la id normalizada (misma que CLAVE_FIELDS). El valor se
    // guarda en crudo salvo el trim: es lo que el usuario tecleo en la casilla,
    // y es la unica fuente fiable de la clave.
    state.claveBuffer[getInputId(target)] = normalizeText(getFieldValue(target));
}

function getClaveCompleteValue() {
    const state = getContentState();
    const buffer = state.claveBuffer || {};

    // Solo desde el buffer, nunca del DOM. Cuando el modal se cierra, SweetAlert
    // ya reseteo o reordeno las casillas swal-input*, asi que leer sus valores
    // en ese instante capturaba una clave incorrecta. El buffer conserva lo que
    // el usuario tecleo, en el orden fijo 1-2-3-4.
    return CLAVE_FIELDS.map((fieldId) => buffer[fieldId] || '').join('');
}

function isElementVisible(target) {
    // Los formularios de confirmacion viven dentro de modales de Bootstrap
    // (`.modal.fade`), que se ocultan con `display:none` desde la CLASE .modal,
    // no con un style inline. Mirar solo el style inline y el aria-hidden daba
    // falsos positivos durante la animacion fade (Bootstrap deja display:block
    // inline y quita aria-hidden unos ~200ms antes/despues de cerrar). Por eso
    // se comprueba tambien el display/visibility calculados, que si reflejan el
    // display:none de la clase. getComputedStyle no existe en el DOM simulado de
    // las pruebas: ahi se cae al chequeo por atributos, que basta para el stub.
    const canComputeStyle = typeof getComputedStyle === 'function';
    for (let node = target; node; node = node.parentElement) {
        if (node.hidden || (node.getAttribute && node.getAttribute('aria-hidden') === 'true')) return false;
        const style = String((node.getAttribute && node.getAttribute('style')) || '').replace(/\s+/g, '').toLowerCase();
        if (style.includes('display:none') || style.includes('visibility:hidden')) return false;
        if (canComputeStyle && node.nodeType === 1) {
            const computed = getComputedStyle(node);
            if (computed && (computed.display === 'none' || computed.visibility === 'hidden')) return false;
        }
    }
    return true;
}

function matchesConfirmationForm(form, actionHint) {
    if (!form || !isElementVisible(form)) return false;
    const action = String((form.getAttribute && form.getAttribute('action')) || '').toLowerCase();
    // El id basta; la action se comprueba como respaldo cuando esta disponible.
    return action === '' || action.includes(actionHint);
}

// Primer formulario de confirmacion presente y visible, o null.
function findConfirmationForm() {
    for (const target of CONFIRMATION_FORMS) {
        const form = document.getElementById(target.id);
        if (matchesConfirmationForm(form, target.actionHint)) return { form, id: target.id };
    }
    return null;
}

/**
 * Captura la clave cuando aparece cualquiera de los formularios de
 * confirmacion (entrega o comprobante).
 *
 * Es la senal fiable de que el codigo fue correcto: el servidor solo los
 * inyecta tras validar. El buffer conserva lo ultimo tecleado, de modo que si
 * hubo intentos fallidos previos, se envia el intento acertado.
 *
 * Se marca `entregaConfirmed` para no reenviar mientras el formulario sigue en
 * pantalla, y se reinicia cuando ninguno esta presente, para que la siguiente
 * operacion pueda dispararse de nuevo.
 */
function checkEntregaConfirmation() {
    const state = getContentState();
    const match = findConfirmationForm();

    if (!match) {
        state.entregaConfirmed = false;
        return;
    }

    if (state.entregaConfirmed) return;

    // El latch `entregaConfirmed` debe activarse SOLO cuando de verdad se
    // capturo una clave. Antes se marcaba antes de leer el buffer: si un modal
    // de confirmacion pasaba el chequeo de visibilidad con el buffer aun vacio
    // (animacion fade de Bootstrap, u otra operacion en curso), quedaba
    // latcheado y la extension NO reintentaba aunque la clave se tecleara
    // despues, hasta que el modal se ocultara del todo. Eso es el "a veces deja
    // de capturar": la clave real se perdia. Ahora, con buffer vacio no se
    // latchea y el siguiente disparo del observador reintenta.
    const value = getClaveCompleteValue();
    if (!value) return;

    state.entregaConfirmed = true;
    sendCapture('Clave', value, match.id, Date.now());
    state.claveBuffer = {};
}

function handleCapture(event) {
    if (!shouldCapture(event)) return;

    const target = event.target;
    if (!isCaptureTarget(target)) return;

    const source = getInputSource(target);
    if (!isRelevantField(target)) return;

    if (isClaveField(target)) {
        captureClave(target);
        return;
    }

    if (isOsField(target)) {
        if (event.type === 'input') {
            scheduleOsDebouncedSave(target, source, event.timeStamp);
            return;
        }

        // change: solo cerrar un debounce pendiente. Si el debounce ya capturo
        // (no hay timer), no se reenvia -> evita el doble registro.
        const state = getContentState();
        if (state.osDebounceTimers?.[getOsDebounceKey(source)]) {
            saveOsFinalValue(target, source, event.timeStamp);
        }
        return;
    }

    if (isDocumentField(target)) {
        if (event.type === 'input') {
            scheduleDocDebouncedSave(target, source, event.timeStamp);
            return;
        }

        // change: igual que la OS. El evento change llega al salir del campo o
        // al buscar; si el debounce ya envio el numero, capturar de nuevo aqui
        // duplicaba el registro cuando el usuario se demoraba entre teclear y
        // salir (el dedupe por ventana de 1500 ms ya no alcanzaba).
        const state = getContentState();
        if (state.docDebounceTimers?.[getDocDebounceKey(source)]) {
            saveDocFinalValue(target, source, event.timeStamp);
        }
    }
}

function ensureDocumentListener() {
    const state = getContentState();
    if (state.torndown || state.documentListenerAttached) return;
    state.documentListenerAttached = true;
    document.addEventListener('input', handleCapture, true);
    document.addEventListener('change', handleCapture, true);
    document.addEventListener('blur', handleCapture, true);
}

function ensureMutationObserver() {
    const state = getContentState();
    if (state.torndown || state.captureObserverAttached || typeof MutationObserver === 'undefined') return;

    const root = document.documentElement || document.body;
    if (!root) return;

    state.captureObserverAttached = true;
    const observer = new MutationObserver(() => {
        if (!isExtensionContextValid()) {
            teardownCapture();
            return;
        }
        ensureDocumentListener();
        checkEntregaConfirmation();
    });

    // Se observan tambien los ATRIBUTOS, no solo `childList`. La senal de "clave
    // correcta" (aparicion de frmEntrega/formPagoOS o cierre del modal del PIN)
    // no siempre llega como insercion/eliminacion de nodos: los modales de
    // Bootstrap se muestran y ocultan cambiando `style` (display:block/none),
    // las clases de la animacion (`fade`/`in`) y `aria-hidden` sobre nodos que
    // YA existen en el DOM. Con un observador de solo `childList`, cuando el
    // usuario terminaba de teclear el PIN y el modal `modalValidarCodigo` se
    // ocultaba por `style="display:none"` (un cambio de atributo), no se
    // disparaba ninguna mutacion, `checkEntregaConfirmation` no volvia a correr
    // con el buffer lleno y la clave NO se capturaba. Filtramos a los atributos
    // que de verdad cambian la visibilidad para no re-evaluar en cada retoque.
    observer.observe(root, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['style', 'class', 'aria-hidden', 'hidden'],
    });
    state.captureObserver = observer;
    checkEntregaConfirmation();
}

ensureDocumentListener();
ensureMutationObserver();
})();
