<?php

namespace App\Http\Requests\Agencies;

use App\Modules\Agencies\Enums\AgencyStatus;
use App\Modules\Agencies\Models\Agency;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreAgencyRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', Agency::class) ?? false;
    }

    public function rules(): array
    {
        return [
            'external_id' => ['nullable', 'integer', 'min:1', 'unique:agencies,external_id'],
            // La abreviatura no identifica una agencia en Shalom y puede
            // repetirse; la unicidad se exige sobre external_id.
            'code' => ['required', 'string', 'max:50'],
            'name' => ['required', 'string', 'max:255'],
            'short_name' => ['nullable', 'string', 'max:255'],
            'department' => ['required', 'string', 'max:255'],
            'province' => ['required', 'string', 'max:255'],
            'district' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string'],
            'reference' => ['nullable', 'string'],
            'phone' => ['nullable', 'string', 'max:50'],
            'secondary_phone' => ['nullable', 'string', 'max:50'],
            'email' => ['nullable', 'email', 'max:255'],
            'schedule' => ['nullable', 'string'],
            'latitude' => ['nullable', 'numeric', 'between:-90,90'],
            'longitude' => ['nullable', 'numeric', 'between:-180,180'],
            'services' => ['required', 'array'],
            'services.*' => ['string', 'max:255'],
            'observations' => ['nullable', 'string'],
            'status' => ['required', Rule::enum(AgencyStatus::class)],
            'source' => ['required', 'string', 'max:255'],
            'source_reference' => ['nullable', 'string', 'max:255'],
            'texto_chosen_terrestre' => ['nullable', 'string', 'max:10000'],
            'texto_chosen_aereo' => ['nullable', 'string', 'max:10000'],
            'last_verified_at' => ['nullable', 'date'],
        ];
    }
}
