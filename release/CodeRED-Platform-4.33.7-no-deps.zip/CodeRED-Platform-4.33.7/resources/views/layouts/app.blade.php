<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="dark h-full scroll-smooth" x-data="sidebar()">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name') }}</title>
    <link rel="icon" href="{{ asset('images/branding/favicon.png') }}">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @livewireStyles
</head>
<body class="h-dvh overflow-hidden bg-[color:var(--color-background)] text-[color:var(--color-text-primary)]">
    <x-ui.toast-stack :messages="[
        ['tone' => 'success', 'message' => session('success')],
        ['tone' => 'danger', 'message' => session('error')],
    ]" />
    <div class="code-red-shell h-dvh min-h-0 overflow-hidden">
        <div class="flex h-dvh min-h-0 overflow-hidden">
            <aside class="layer-sidebar group fixed inset-y-0 left-0 z-40 hidden h-dvh min-h-0 flex-col border-r border-[color:var(--color-border-subtle)] bg-[color:var(--color-sidebar)]/95 backdrop-blur lg:flex transition-[width] duration-300 ease-in-out"
                   :class="collapsed ? 'lg:w-[76px]' : 'lg:w-[264px]'">
                <div class="relative shrink-0 border-b border-white/5 px-4 py-5">
                    <div class="flex items-center justify-center">
                        <a href="{{ route('dashboard') }}">
                            <x-ui.logo variant="symbol" class="h-10 w-10 rounded-xl shrink-0" />
                        </a>
                        <div class="ml-3" x-show="!collapsed" x-cloak>
                            <p class="text-base font-semibold tracking-tight">CodeRED Platform</p>
                            <p class="text-xs text-[color:var(--color-text-secondary)]">Plataforma modular · v{{ config('version.current') }}</p>
                        </div>
                    </div>
                     <button
                        type="button"
                        @click="toggleCollapse"
                        :aria-expanded="!collapsed"
                        :title="collapsed ? 'Expandir barra lateral' : 'Ocultar barra lateral'"
                        class="absolute -right-4 top-8 z-10 flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 shadow-lg backdrop-blur transition-all duration-200 hover:scale-110 hover:border-brand-light/50 hover:text-white"
                     >
                        <svg :class="!collapsed ? '' : 'rotate-180'" class="h-4 w-4 transition-transform" viewBox="0 0 16 16" fill="currentColor"><path fill-rule="evenodd" d="M6.22 3.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L9.94 8 6.22 4.28a.75.75 0 0 1 0-1.06Z"></path></svg>
                    </button>
                </div>

                <nav
                    class="sidebar-navigation min-h-0 flex-1 overflow-y-auto overscroll-contain text-sm [scrollbar-gutter:stable]"
                    :class="collapsed ? 'p-2' : 'p-4'"
                    data-sidebar-navigation
                    x-data="codeRedSidebarScroll"
                    x-on:scroll.passive="remember"
                >
                    @php
                        $menuUser = auth()->user();
                        $isViewerOnly = $menuUser->hasPermission('agencies.view')
                            && $menuUser->hasPermission('agencies.map')
                            && $menuUser->hasPermission('shalom-recordar.view-own')
                            && ! $menuUser->hasPermission('dashboard.view')
                            && ! $menuUser->hasPermission('users.view')
                            && ! $menuUser->hasPermission('agencies.backup.view')
                            && ! $menuUser->hasPermission('settings.api-documentation.update')
                            && ! $menuUser->hasPermission('settings.agency-backups.update')
                            && ! $menuUser->hasPermission('settings.ubigeos.update')
                            && ! $menuUser->hasPermission('integrations.n8n.manage')
                            && ! $menuUser->isSuperAdmin();
                        $navGroups = [
                            'General' => $isViewerOnly ? [] : [
                                ['label' => 'Dashboard', 'route' => 'dashboard', 'icon' => '⌂', 'can' => $menuUser->hasPermission('dashboard.view')],
                            ],
                            'Agencias' => [
                                ['label' => 'Listado', 'route' => 'admin.agencies.index', 'icon' => '◎', 'can' => Gate::allows('viewAny', \App\Modules\Agencies\Models\Agency::class)],
                                ['label' => 'Mapa de agencias', 'route' => 'admin.agencies.map', 'icon' => '⌖', 'can' => Gate::allows('viewAny', \App\Modules\Agencies\Models\Agency::class)],
                                ['label' => 'Sincronizar Shalom', 'route' => 'admin.agencies.import.shalom', 'icon' => '⇪', 'can' => ! $isViewerOnly && Gate::allows('import', \App\Modules\Agencies\Models\Agency::class)],
                                ['label' => 'Copias de seguridad', 'route' => 'admin.agencies.backups.index', 'icon' => '▣', 'can' => ! $isViewerOnly && $menuUser->hasPermission('agencies.backup.view')],
                            ],
                            'Identidad' => [
                                ['label' => 'Probar API DNI', 'route' => 'admin.api-tools.dni', 'icon' => '⌕', 'can' => ! $isViewerOnly && $menuUser->hasPermission('api-tools.dni.test')],
                                ['label' => 'Buscar DNI por nombres', 'route' => 'admin.api-tools.dni-name-search', 'icon' => '⌗', 'can' => ! $isViewerOnly && $menuUser->hasPermission('dni-records.view')],
                                ['label' => 'Configuración DNI', 'route' => 'admin.settings.dni', 'icon' => '⚙', 'can' => ! $isViewerOnly && $menuUser->hasPermission('settings.dni.view')],
                                // Sin el filtro !$isViewerOnly que usan los demás enlaces de este
                                // grupo: un viewer puro SÍ tiene declaracion-jurada.view por
                                // defecto (ver PermissionsSeeder), así que el permiso ya es la
                                // única condición — ocultarle el enlace además dejaría el acceso
                                // otorgado sin ninguna forma de encontrarlo desde el panel.
                                ['label' => 'Declaración Jurada', 'url' => config('services.declaracion_jurada.url'), 'icon' => '⇗', 'can' => $menuUser->hasPermission('declaracion-jurada.view') && filled(config('services.declaracion_jurada.url'))],
                            ],
                            'Empresas y RUC' => [
                                ['label' => 'Probar API RUC', 'route' => 'admin.api-tools.ruc', 'icon' => '⌕', 'can' => ! $isViewerOnly && $menuUser->hasPermission('ruc.test')],
                                ['label' => 'Buscar Representantes', 'route' => 'admin.api-tools.ruc-representantes', 'icon' => '♙', 'can' => ! $isViewerOnly && $menuUser->hasPermission('ruc.representantes')],
                                ['label' => 'Padrón RUC', 'route' => 'admin.ruc.records', 'icon' => '▦', 'can' => ! $isViewerOnly && $menuUser->hasPermission('ruc.view')],
                                ['label' => 'Backups RUC', 'route' => 'admin.ruc.backups', 'icon' => '⛁', 'can' => ! $isViewerOnly && $menuUser->hasPermission('ruc.backup.view')],
                            ],
                            'API' => [
                                ['label' => 'Tokens', 'route' => 'admin.api-tokens.index', 'icon' => '◇', 'can' => ! $isViewerOnly && $menuUser->hasPermission('api-tokens.view-any')],
                                ['label' => 'Solicitudes de tokens', 'route' => 'admin.api-token-requests.index', 'icon' => '◇', 'can' => ! $isViewerOnly && $menuUser->hasPermission('api-token-requests.view')],
                                ['label' => 'Solicitudes de acceso', 'route' => 'admin.permission-requests.index', 'icon' => '◈', 'can' => ! $isViewerOnly && $menuUser->hasPermission('permission-requests.view')],
                                ['label' => 'Shalom Recordar', 'route' => 'admin.shalom-recordar.index', 'icon' => '◫', 'can' => $menuUser->hasPermission('shalom-recordar.view')],
                                ['label' => 'Documentación', 'route' => 'api.docs', 'icon' => '▤', 'can' => true],
                            ],
                            'Administración' => $isViewerOnly ? [] : [
                                ['label' => 'Usuarios', 'route' => 'admin.users.index', 'icon' => '◔', 'can' => Gate::allows('viewAny', \App\Models\User::class)],
                                ['label' => 'Design System', 'route' => 'admin.design-system', 'icon' => '✦', 'can' => $menuUser->isSuperAdmin()],
                            ],
                            'Configuración' => $isViewerOnly ? [] : [
                                ['label' => 'Documentación API', 'route' => 'admin.settings.api-documentation', 'icon' => '⚙', 'can' => $menuUser->hasPermission('settings.api-documentation.update')],
                                ['label' => 'Copias de agencias', 'route' => 'admin.settings.agency-backups', 'icon' => '⚙', 'can' => $menuUser->hasPermission('settings.agency-backups.update')],
                                ['label' => 'Ubigeos', 'route' => 'admin.settings.ubigeos', 'icon' => '⌖', 'can' => $menuUser->hasPermission('settings.ubigeos.update')],
                                ['label' => 'Bloqueo extensión', 'route' => 'admin.settings.extension-blocking', 'icon' => '⏱', 'can' => $menuUser->hasPermission('settings.extension-blocking.view')],
                                ['label' => 'n8n', 'route' => 'admin.integrations.n8n', 'icon' => '↗', 'can' => $menuUser->hasPermission('integrations.n8n.manage')],
                            ],
                        ];
                    @endphp

                    <div class="flex flex-col gap-y-1">
                    @foreach ($navGroups as $group => $items)
                        @if(collect($items)->contains('can', true))
                        <div class="space-y-1">
                            <p class="px-3 pb-1 pt-4 text-[0.65rem] font-semibold uppercase tracking-[0.2em] text-[color:var(--color-text-muted)] first:pt-0" x-show="!collapsed" x-cloak>
                                <span>{{ $group }}</span>
                            </p>
                            @foreach ($items as $item)
                              @if ($item['can'])
                                <div class="relative group" x-data="{ active: {{ !empty($item['url']) ? 'false' : (request()->routeIs($item['route']) ? 'true' : 'false') }} }">
                                    <a href="{{ $item['url'] ?? route($item['route']) }}"
                                       @if(!empty($item['url'])) target="_blank" rel="noopener noreferrer" @endif
                                       :aria-current="active ? 'page' : 'false'"
                                       class="flex items-center gap-3 rounded-lg px-3 py-2 transition-colors duration-200"
                                       :class="{
                                            'justify-center': collapsed,
                                            'bg-brand-soft text-brand-light': !collapsed && active,
                                            'text-gray-400 hover:bg-surface-hover hover:text-white': !collapsed && !active,
                                            'bg-white/10 text-white': collapsed && active,
                                            'text-gray-400 hover:bg-white/5 hover:text-white': collapsed && !active
                                       }">
                                        <span class="inline-flex h-8 w-8 items-center justify-center rounded-xl text-lg shrink-0">{{ $item['icon'] }}</span>
                                        <span class="font-medium text-sm" x-show="!collapsed" x-cloak>{{ $item['label'] }}</span>
                                    </a>
                                    <div x-show="collapsed" x-cloak
                                         class="pointer-events-none absolute left-full top-1/2 ml-3 -translate-y-1/2 whitespace-nowrap rounded-lg border border-border-subtle bg-surface px-3 py-2 text-sm text-text-primary opacity-0 invisible shadow-xl transition-all duration-150 group-hover:visible group-hover:opacity-100 group-hover:delay-500 z-10">
                                        {{ $item['label'] }}
                                        <div class="absolute -left-1 top-1/2 -translate-y-1/2 h-2 w-2 rotate-45 bg-surface border-l border-b border-border-subtle"></div>
                                    </div>
                                </div>
                              @endif
                            @endforeach
                        </div>
                        @endif
                    @endforeach
                    </div>
                </nav>

                <div class="mt-auto shrink-0 border-t border-white/5" :class="collapsed ? 'p-2' : 'p-4'">
                    <a href="{{ route('profile.show') }}" aria-label="Abrir mi perfil"
                       :class="[
                           'focus-ring flex items-center gap-3 rounded-xl p-2 transition-colors hover:bg-white/10',
                           collapsed ? 'justify-center' : ''
                       ]">
                        <x-ui.avatar :name="auth()->user()->name" size="sm" class="shrink-0"/>
                        <div class="min-w-0 flex-1" x-show="!collapsed" x-cloak>
                            <p class="truncate text-sm font-medium">{{ auth()->user()->name }}</p>
                            <p class="truncate text-xs text-gray-400">{{ auth()->user()->email }}</p>
                        </div>
                    </a>
                </div>
            </aside>

            <div class="flex h-dvh min-h-0 flex-1 flex-col overflow-hidden transition-[margin-left] duration-300 ease-in-out"
                 :class="!collapsed ? 'lg:ml-[264px]' : 'lg:ml-[76px]'">
                <header class="layer-header shrink-0 border-b border-[color:var(--color-border-subtle)] bg-[color:var(--color-background-elevated)]/90 backdrop-blur">
                    <div class="flex items-center justify-between gap-4 px-4 py-4 lg:px-8">
                        <div class="flex items-center gap-3">
                            <x-ui.icon-button class="h-11 w-11 lg:hidden" x-on:click="mobileOpen = true" label="Abrir menú">
                                <span class="text-xl">☰</span>
                            </x-ui.icon-button>
                            <div>
                                <p class="text-xs uppercase tracking-[0.24em] text-[color:var(--color-text-muted)]">CodeRED Platform</p>
                                <h1 class="font-display text-lg font-semibold text-white">{{ $pageTitle ?? 'Panel administrativo' }}</h1>
                            </div>
                        </div>

                        <div class="flex items-center gap-2">
                            @auth
                                @php
                                    $menuUser = auth()->user();
                                @endphp
                                <div class="relative" x-data="{ open: false }" x-on:keydown.escape.window="open = false">
                                    <button type="button"
                                            class="focus-ring flex items-center gap-2 rounded-full"
                                            x-on:click="open = !open"
                                            :aria-expanded="open ? 'true' : 'false'"
                                            aria-haspopup="menu"
                                            aria-label="Menú de usuario">
                                        <x-ui.avatar :name="$menuUser->name" size="sm" class="shrink-0" />
                                    </button>

                                    <div x-cloak
                                         x-show="open"
                                         x-transition.origin.top.right
                                         x-on:click.outside="open = false"
                                         class="layer-popover absolute right-0 z-50 mt-2 w-64 overflow-hidden rounded-[var(--radius-card)] border border-[color:var(--color-border-subtle)] bg-[color:var(--color-background-elevated)] shadow-2xl"
                                         role="menu"
                                         aria-label="Cuenta">
                                        <div class="border-b border-white/5 px-4 py-3">
                                            <p class="truncate text-sm font-semibold text-white">{{ $menuUser->name }}</p>
                                            <p class="truncate text-xs text-[color:var(--color-text-secondary)]">{{ $menuUser->email }}</p>
                                            <span class="mt-2 inline-flex items-center rounded-full bg-white/5 px-2 py-0.5 text-[11px] font-medium text-[color:var(--color-text-secondary)]">{{ $menuUser->primaryRoleLabel() }}</span>
                                        </div>
                                        <div class="p-1.5" role="none">
                                            <a href="{{ route('profile.show') }}" role="menuitem"
                                               class="focus-ring flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-[color:var(--color-text-primary)] transition hover:bg-white/5">
                                                <span aria-hidden="true">👤</span> Perfil
                                            </a>
                                            @if ($menuUser->hasPermission('shalom-recordar.view-own') && ! $menuUser->hasPermission('shalom-recordar.view'))
                                                <a href="{{ route('admin.shalom-recordar.users.show', $menuUser) }}" role="menuitem"
                                                   class="focus-ring flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-[color:var(--color-text-primary)] transition hover:bg-white/5">
                                                    <span aria-hidden="true">🔄</span> Mis sincronizaciones
                                                </a>
                                            @endif
                                        </div>
                                        <div class="border-t border-white/5 p-1.5" role="none">
                                            <form method="post" action="{{ route('logout') }}">
                                                @csrf
                                                <button type="submit" role="menuitem"
                                                        class="focus-ring flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-[color:var(--color-danger)] transition hover:bg-[color:var(--color-danger)]/10">
                                                    <span aria-hidden="true">⇥</span> Cerrar sesión
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            @endauth
                        </div>
                    </div>
                </header>

                <main class="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-6 lg:px-8 lg:py-8" id="main-content">
                    <div class="mx-auto w-full max-w-[1680px]">{{ $slot }}</div>
                    <footer class="mx-auto mt-8 w-full max-w-[1680px] border-t border-white/5 pt-4 text-xs text-[color:var(--color-text-muted)]">CodeRED Platform v{{ config('version.current') }}</footer>
                </main>
            </div>
        </div>

        <div x-cloak x-show="mobileOpen" class="layer-popover fixed inset-0 z-50 h-dvh overflow-hidden lg:hidden">
            <div class="absolute inset-0 bg-black/70" x-on:click="mobileOpen = false" x-transition:opacity></div>
            <aside class="absolute inset-y-0 left-0 flex h-dvh min-h-0 w-[86vw] max-w-sm flex-col overflow-hidden border-r border-white/10 bg-[color:var(--color-sidebar)] shadow-2xl"
                   x-show="mobileOpen"
                   x-transition:enter="transition ease-in-out duration-300"
                   x-transition:enter-start="-translate-x-full"
                   x-transition:enter-end="translate-x-0"
                   x-transition:leave="transition ease-in-out duration-300"
                   x-transition:leave-start="translate-x-0"
                   x-transition:leave-end="-translate-x-full">
                <div class="flex shrink-0 items-center justify-between p-5 pb-0">
                    <x-ui.logo variant="symbol" class="h-10 w-10 rounded-xl" />
                    <x-ui.icon-button x-on:click="mobileOpen = false" label="Cerrar menú">✕</x-ui.icon-button>
                </div>
                <div class="mx-5 mt-5 shrink-0 border-b border-white/5 pb-4">
                    <a href="{{ route('profile.show') }}" class="focus-ring flex items-center gap-3 rounded-2xl bg-white/5 p-3">
                        <x-ui.avatar :name="auth()->user()->name" size="sm" />
                        <div class="min-w-0"><p class="truncate text-sm font-medium">{{ auth()->user()->name }}</p><p class="truncate text-xs text-[color:var(--color-text-secondary)]">Mi perfil</p></div>
                    </a>
                </div>
                <nav class="sidebar-navigation mt-5 min-h-0 flex-1 space-y-2 overflow-y-auto overscroll-contain px-5 pb-5 [scrollbar-gutter:stable]" data-sidebar-navigation x-data="codeRedSidebarScroll" x-on:scroll.passive="remember" x-on:click="if ($event.target.closest('a')) mobileOpen = false">
                    @php
                        $navGroups = [
                            'General' => [
                                ['label' => 'Dashboard', 'route' => 'dashboard', 'icon' => '⌂', 'can' => $menuUser->hasPermission('dashboard.view')],
                            ],
                            'Agencias' => [
                                ['label' => 'Listado', 'route' => 'admin.agencies.index', 'icon' => '◎', 'can' => Gate::allows('viewAny', \App\Modules\Agencies\Models\Agency::class)],
                                ['label' => 'Mapa de agencias', 'route' => 'admin.agencies.map', 'icon' => '⌖', 'can' => Gate::allows('viewAny', \App\Modules\Agencies\Models\Agency::class)],
                                ['label' => 'Sincronizar Shalom', 'route' => 'admin.agencies.import.shalom', 'icon' => '⇪', 'can' => ! $isViewerOnly && Gate::allows('import', \App\Modules\Agencies\Models\Agency::class)],
                                ['label' => 'Copias de seguridad', 'route' => 'admin.agencies.backups.index', 'icon' => '▣', 'can' => ! $isViewerOnly && $menuUser->hasPermission('agencies.backup.view')],
                            ],
                            'Identidad' => [
                                ['label' => 'Probar API DNI', 'route' => 'admin.api-tools.dni', 'icon' => '⌕', 'can' => ! $isViewerOnly && $menuUser->hasPermission('api-tools.dni.test')],
                                ['label' => 'Buscar DNI por nombres', 'route' => 'admin.api-tools.dni-name-search', 'icon' => '⌗', 'can' => ! $isViewerOnly && $menuUser->hasPermission('dni-records.view')],
                                ['label' => 'Configuración DNI', 'route' => 'admin.settings.dni', 'icon' => '⚙', 'can' => ! $isViewerOnly && $menuUser->hasPermission('settings.dni.view')],
                                // Sin el filtro !$isViewerOnly que usan los demás enlaces de este
                                // grupo: un viewer puro SÍ tiene declaracion-jurada.view por
                                // defecto (ver PermissionsSeeder), así que el permiso ya es la
                                // única condición — ocultarle el enlace además dejaría el acceso
                                // otorgado sin ninguna forma de encontrarlo desde el panel.
                                ['label' => 'Declaración Jurada', 'url' => config('services.declaracion_jurada.url'), 'icon' => '⇗', 'can' => $menuUser->hasPermission('declaracion-jurada.view') && filled(config('services.declaracion_jurada.url'))],
                            ],
                            'Empresas y RUC' => [
                                ['label' => 'Probar API RUC', 'route' => 'admin.api-tools.ruc', 'icon' => '⌕', 'can' => ! $isViewerOnly && $menuUser->hasPermission('ruc.test')],
                                ['label' => 'Buscar Representantes', 'route' => 'admin.api-tools.ruc-representantes', 'icon' => '♙', 'can' => ! $isViewerOnly && $menuUser->hasPermission('ruc.representantes')],
                                ['label' => 'Padrón RUC', 'route' => 'admin.ruc.records', 'icon' => '▦', 'can' => ! $isViewerOnly && $menuUser->hasPermission('ruc.view')],
                                ['label' => 'Backups RUC', 'route' => 'admin.ruc.backups', 'icon' => '⛁', 'can' => ! $isViewerOnly && $menuUser->hasPermission('ruc.backup.view')],
                            ],
                            'API' => [
                                ['label' => 'Tokens', 'route' => 'admin.api-tokens.index', 'icon' => '◇', 'can' => ! $isViewerOnly && $menuUser->hasPermission('api-tokens.view-any')],
                                ['label' => 'Solicitudes de tokens', 'route' => 'admin.api-token-requests.index', 'icon' => '◇', 'can' => ! $isViewerOnly && $menuUser->hasPermission('api-token-requests.view')],
                                ['label' => 'Solicitudes de acceso', 'route' => 'admin.permission-requests.index', 'icon' => '◈', 'can' => ! $isViewerOnly && $menuUser->hasPermission('permission-requests.view')],
                                ['label' => 'Shalom Recordar', 'route' => 'admin.shalom-recordar.index', 'icon' => '◫', 'can' => $menuUser->hasPermission('shalom-recordar.view')],
                                ['label' => 'Documentación', 'route' => 'api.docs', 'icon' => '▤', 'can' => true],
                            ],
                            'Administración' => [
                                ['label' => 'Usuarios', 'route' => 'admin.users.index', 'icon' => '◔', 'can' => Gate::allows('viewAny', \App\Models\User::class)],
                                ['label' => 'Design System', 'route' => 'admin.design-system', 'icon' => '✦', 'can' => $menuUser->isSuperAdmin()],
                            ],
                            'Configuración' => [
                                ['label' => 'Documentación API', 'route' => 'admin.settings.api-documentation', 'icon' => '⚙', 'can' => $menuUser->hasPermission('settings.api-documentation.update')],
                                ['label' => 'Copias de agencias', 'route' => 'admin.settings.agency-backups', 'icon' => '⚙', 'can' => $menuUser->hasPermission('settings.agency-backups.update')],
                                ['label' => 'Ubigeos', 'route' => 'admin.settings.ubigeos', 'icon' => '⌖', 'can' => $menuUser->hasPermission('settings.ubigeos.update')],
                                ['label' => 'Bloqueo extensión', 'route' => 'admin.settings.extension-blocking', 'icon' => '⏱', 'can' => $menuUser->hasPermission('settings.extension-blocking.view')],
                                ['label' => 'n8n', 'route' => 'admin.integrations.n8n', 'icon' => '↗', 'can' => $menuUser->hasPermission('integrations.n8n.manage')],
                            ],
                        ];
                    @endphp
                    @foreach ($navGroups as $group => $items)
                        @if(collect($items)->contains('can', true))<p class="px-4 pb-1 pt-3 text-[0.65rem] font-semibold uppercase tracking-[0.2em] text-[color:var(--color-text-muted)] first:pt-0">{{ $group }}</p>@endif
                        @foreach ($items as $item)
                            @if($item['can'])
                                <a
                                    href="{{ $item['url'] ?? route($item['route']) }}"
                                    @if(!empty($item['url'])) target="_blank" rel="noopener noreferrer" @endif
                                    @if(empty($item['url']) && request()->routeIs($item['route'])) data-sidebar-active="true" aria-current="page" @endif
                                    @class([
                                        'sidebar-link',
                                    ])
                                >{{ $item['label'] }}</a>
                            @endif
                        @endforeach
                    @endforeach
                </nav>
                <form method="post" action="{{ route('logout') }}" class="shrink-0 border-t border-white/5 p-5">
                    @csrf
                    <x-ui.button variant="secondary" size="sm" type="submit" class="w-full">Cerrar sesión</x-ui.button>
                </form>
            </aside>
        </div>
    </div>
    @livewireScripts
</body>
</html>
