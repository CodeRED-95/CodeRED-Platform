<?php

use App\Http\Controllers\Api\V1\ActivityController;
use App\Http\Controllers\Api\V1\Admin\AdminPermissionRequestController;
use App\Http\Controllers\Api\V1\Admin\AdminTokenController;
use App\Http\Controllers\Api\V1\Admin\AdminTokenRequestController;
use App\Http\Controllers\Api\V1\Admin\AdminUserController;
use App\Http\Controllers\Api\V1\AgenciesController;
use App\Http\Controllers\Api\V1\AgencyCatalogController;
use App\Http\Controllers\Api\V1\AgencyChangesController;
use App\Http\Controllers\Api\V1\Auth\AuthController as ClientAuthController;
use App\Http\Controllers\Api\V1\Auth\EmailVerificationController;
use App\Http\Controllers\Api\V1\Auth\SessionController as ClientSessionController;
use App\Http\Controllers\Api\V1\CatalogMetadataController;
use App\Http\Controllers\Api\V1\DeclarationController;
use App\Http\Controllers\Api\V1\DesktopUpdateController;
use App\Http\Controllers\Api\V1\DniApiController;
use App\Http\Controllers\Api\V1\DniNameSearchController;
use App\Http\Controllers\Api\V1\ExtensionBlockRulesController;
use App\Http\Controllers\Api\V1\ExtensionChromeConfigController;
use App\Http\Controllers\Api\V1\HealthController;
use App\Http\Controllers\Api\V1\Integrations\IntegrationDiscoveryController;
use App\Http\Controllers\Api\V1\Integrations\N8nTelegramPersonalCodeController;
use App\Http\Controllers\Api\V1\Integrations\N8nTokenRequestController;
use App\Http\Controllers\Api\V1\MeController;
use App\Http\Controllers\Api\V1\Mobile\AuthController as MobileAuthController;
use App\Http\Controllers\Api\V1\Mobile\PermissionRequestController;
use App\Http\Controllers\Api\V1\MobileDeviceController;
use App\Http\Controllers\Api\V1\NotificationController;
use App\Http\Controllers\Api\V1\RucRepresentativeController;
use App\Http\Controllers\Api\V1\ShalomRecordarAuthController;
use App\Http\Controllers\Api\V1\SystemVersionController;
use App\Http\Controllers\Api\V1\TokenRequestController as PublicTokenRequestController;
use App\Http\Controllers\Api\V1\TokenRotationRequestController;
use App\Http\Controllers\Api\V1\Webhooks\ResendWebhookController;
use App\Modules\ExtensionControl\Support\BlockingAbility;
use App\Modules\Ruc\Http\Controllers\RucApiController;
use App\Modules\Ruc\Http\Controllers\RucSearchApiController;
use App\Modules\Shalom\Http\Controllers\DeliveryRecordsExportController;
use App\Modules\Shalom\Http\Controllers\ShalomSyncController;
use App\Modules\Shalom\Http\Middleware\AuthenticateShalomApiKey;
use App\Modules\ShalomRecordar\Http\Controllers\ShalomRecordarSyncController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->name('api.v1.')->group(function (): void {
    Route::get('/health', HealthController::class)->name('health');
    Route::post('/webhooks/resend', ResendWebhookController::class)->middleware('throttle:api')->name('webhooks.resend');
    Route::get('/version', SystemVersionController::class)->name('version');
    Route::get('/extension/chrome/config', ExtensionChromeConfigController::class)->middleware('throttle:api')->name('extension.chrome.config');
    // Canal de actualizacion de CodeRED Desktop. Publico a proposito: la
    // aplicacion comprueba si hay version nueva antes de tener credencial
    // alguna, y quien la usa con un token de API tampoco tiene sesion.
    Route::get('/desktop/update', DesktopUpdateController::class)->middleware('throttle:api')->name('desktop.update');
    Route::post('/shalom/sync', [ShalomSyncController::class, 'sync'])
        ->middleware(['throttle:100,1', AuthenticateShalomApiKey::class])
        ->name('shalom.sync');
    Route::post('/token-requests', PublicTokenRequestController::class)->middleware('throttle:api')->name('token-requests.store');
    Route::get('/integrations/discovery', [IntegrationDiscoveryController::class, 'index'])->name('integrations.discovery');
    Route::post('/integrations/n8n/pair', [IntegrationDiscoveryController::class, 'pair'])->middleware('throttle:api')->name('integrations.n8n.pair');
    Route::post('/integrations/pair', [IntegrationDiscoveryController::class, 'pair'])->middleware('throttle:api')->name('integrations.pair');
    Route::middleware('integration.hmac')->prefix('integrations')->name('integrations.')->group(function (): void {
        Route::post('/discovery', [IntegrationDiscoveryController::class, 'register'])->name('discovery.register');
        Route::post('/heartbeat', [IntegrationDiscoveryController::class, 'heartbeat'])->name('heartbeat');
        Route::post('/challenge', [IntegrationDiscoveryController::class, 'challenge'])->name('challenge');
        Route::post('/rotate-secret', [IntegrationDiscoveryController::class, 'rotateSecret'])->name('secret.rotate');
        Route::post('/rotate-secret/confirm', [IntegrationDiscoveryController::class, 'confirmSecret'])->name('secret.confirm');
        Route::post('/disconnect', [IntegrationDiscoveryController::class, 'disconnect'])->name('disconnect');
    });
    Route::middleware('integration.hmac')->prefix('integrations/n8n')->name('integrations.n8n.')->group(function (): void {
        Route::post('/discovery', [IntegrationDiscoveryController::class, 'register'])->name('discovery.register');
        Route::post('/heartbeat', [IntegrationDiscoveryController::class, 'heartbeat'])->name('heartbeat');
        Route::post('/secret/rotate', [IntegrationDiscoveryController::class, 'rotateSecret'])->name('secret.rotate');
        Route::post('/secret/confirm', [IntegrationDiscoveryController::class, 'confirmSecret'])->name('secret.confirm');
        Route::post('/challenge', [IntegrationDiscoveryController::class, 'challenge'])->name('challenge');
        Route::post('/personal-code', [N8nTelegramPersonalCodeController::class, 'show'])->name('personal-code.show');
        Route::post('/token-requests/rotation-by-code', [N8nTelegramPersonalCodeController::class, 'rotation'])->name('token-requests.rotation-by-code');
        Route::post('/token-requests', [N8nTokenRequestController::class, 'store'])->name('token-requests.store');
        Route::get('/token-requests/{request_uuid}', [N8nTokenRequestController::class, 'show'])->name('token-requests.show');
        Route::post('/token-requests/{request_uuid}/retrieve', [N8nTokenRequestController::class, 'retrieve'])->name('token-requests.retrieve');
        Route::post('/token-requests/{request_uuid}/delivery', [N8nTokenRequestController::class, 'delivery'])->name('token-requests.delivery');
        Route::post('/token-requests/{request_uuid}/cancel', [N8nTokenRequestController::class, 'cancel'])->name('token-requests.cancel');
    });
    Route::prefix('shalom-recordar')->name('shalom-recordar.')->group(function (): void {
        Route::post('/auth/login', [ShalomRecordarAuthController::class, 'login'])
            ->middleware(['throttle:shalom-recordar'])
            ->name('auth.login');
    });
    // Autenticacion de personas en los clientes oficiales. Unico punto donde se
    // validan credenciales de usuario para Platform, Mobile y Desktop.
    //
    // /mobile/* se conserva intacto mas abajo durante la migracion: los clientes
    // publicados siguen funcionando hasta que se actualicen.
    Route::prefix('auth')->name('auth.')->group(function (): void {
        Route::post('/email/send-code', [EmailVerificationController::class, 'send'])->middleware('throttle:email-verification-send')->name('email.send-code');
        Route::post('/email/verify-code', [EmailVerificationController::class, 'verify'])->middleware('throttle:email-verification-verify')->name('email.verify-code');
        Route::post('/email/resend-code', [EmailVerificationController::class, 'resend'])->middleware('throttle:email-verification-send')->name('email.resend-code');
        Route::post('/login', [ClientAuthController::class, 'login'])->middleware('throttle:auth-login')->name('login');
        Route::post('/refresh', [ClientAuthController::class, 'refresh'])->middleware('throttle:auth-refresh')->name('refresh');

        // access:profile:read va en el grupo, no en cada ruta: ademas de
        // autorizar, es quien resuelve la sesion del token y la deja en la
        // peticion. Sin el, /logout y /sessions no sabrian cual es la actual.
        Route::middleware(['auth:sanctum', 'api.token-owner-active', 'throttle:api-mobile', 'access:profile:read'])->group(function (): void {
            Route::get('/me', [ClientAuthController::class, 'me'])->name('me');
            Route::post('/logout', [ClientAuthController::class, 'logout'])->name('logout');
            Route::get('/sessions', [ClientSessionController::class, 'index'])->name('sessions.index');
            Route::delete('/sessions', [ClientSessionController::class, 'destroyAll'])->name('sessions.destroy-all');
            Route::delete('/sessions/{uuid}', [ClientSessionController::class, 'destroy'])->name('sessions.destroy');
        });
    });

    Route::prefix('mobile')->name('mobile.')->group(function (): void {
        Route::post('/login', [MobileAuthController::class, 'login'])->middleware('throttle:api-mobile')->name('login');

        Route::middleware(['auth:sanctum', 'api.token-owner-active', 'throttle:api-mobile'])->group(function (): void {
            Route::get('/me', [MobileAuthController::class, 'me'])->name('me');
            Route::post('/logout', [MobileAuthController::class, 'logout'])->name('logout');
        });
    });
    Route::middleware(['auth:sanctum', 'api.token-owner-active', 'api.private-cache'])->group(function (): void {
        // access:extension:blocking -> la ability tiene que estar declarada en el
        // token. Se concede token a token desde /admin/api-tokens: una
        // instalacion sin ella recibe 403 y no aplica ningun bloqueo.
        Route::get('/extension/chrome/block-rules', ExtensionBlockRulesController::class)
            ->middleware(['throttle:api', 'access:'.BlockingAbility::NAME])
            ->name('extension.chrome.block-rules');
        Route::prefix('shalom-recordar')->name('shalom-recordar.')->group(function (): void {
            Route::post('/installation', [ShalomRecordarSyncController::class, 'register'])
                ->middleware(['throttle:shalom-recordar'])
                ->name('installation.register');
            Route::post('/installations/register', [ShalomRecordarSyncController::class, 'register'])
                ->middleware(['throttle:shalom-recordar'])
                ->name('installations.register');
            Route::post('/sync', [ShalomRecordarSyncController::class, 'sync'])
                ->middleware(['throttle:shalom-recordar'])
                ->name('sync');
            Route::get('/sync/status', [ShalomRecordarSyncController::class, 'status'])
                ->middleware(['throttle:shalom-recordar'])
                ->name('sync.status');
            // Cierre de sesión de la extensión: revoca el token en uso sin
            // tocar los registros locales ni los ya sincronizados.
            Route::post('/auth/logout', [ShalomRecordarSyncController::class, 'logout'])
                ->middleware(['throttle:shalom-recordar'])
                ->name('auth.logout');
        });
        Route::middleware(['throttle:api-agencias', 'api.audit:agencias', 'access:agencias:consultar'])->group(function (): void {
            Route::get('/agencias', [AgencyCatalogController::class, 'index'])->name('agencias.index');
            Route::get('/agencias/{id}', [AgencyCatalogController::class, 'showById'])->name('agencias.show');
        });
        // api.delegate-user permite que el bridge Node de Declaración Jurada
        // (packages/shalom-declaracion-jurada) actúe en nombre del usuario que
        // tiene la sesión abierta allí, con su propio token técnico. Sin él, el
        // paquete React no tendría forma de atribuir cada declaración a su autor.
        Route::middleware(['throttle:api-declaraciones', 'api.audit:declaraciones', 'api.delegate-user', 'access:declaraciones:gestionar'])->group(function (): void {
            Route::get('/declarations', [DeclarationController::class, 'index'])->name('declarations.index');
            Route::post('/declarations', [DeclarationController::class, 'store'])->name('declarations.store');
            Route::get('/declarations/{id}', [DeclarationController::class, 'show'])->whereNumber('id')->name('declarations.show');
            Route::get('/declarations/{id}/pdf', [DeclarationController::class, 'pdf'])->whereNumber('id')->name('declarations.pdf');
        });
        // Administración desde CodeRED Mobile. Cada área tiene su ability y,
        // dentro, cada acción su permiso RBAC: tener `admin:tokens` no basta
        // para revocar, hace falta además `api-tokens.revoke-any`.
        //
        // Reutilizan el sistema real de la plataforma —Sanctum sobre
        // personal_access_tokens, y las acciones compartidas con el panel web
        // para aprobar y rechazar—, así que la auditoría y la emisión ocurren
        // en un único sitio.
        Route::prefix('admin')->name('admin.')->middleware(['throttle:api-admin', 'api.audit:admin'])->group(function (): void {
            Route::middleware(['access:admin:tokens'])->group(function (): void {
                Route::get('/tokens', [AdminTokenController::class, 'index'])->name('tokens.index');
                Route::get('/tokens/types', [AdminTokenController::class, 'types'])->name('tokens.types');
                Route::post('/tokens', [AdminTokenController::class, 'store'])->name('tokens.store');
                Route::delete('/tokens/{id}', [AdminTokenController::class, 'destroy'])->whereNumber('id')->name('tokens.destroy');
            });
            Route::middleware(['access:admin:solicitudes'])->group(function (): void {
                Route::get('/token-requests', [AdminTokenRequestController::class, 'index'])->name('token-requests.index');
                Route::get('/token-requests/{id}', [AdminTokenRequestController::class, 'show'])->whereNumber('id')->name('token-requests.show');
                Route::post('/token-requests/{id}/approve', [AdminTokenRequestController::class, 'approve'])->whereNumber('id')->name('token-requests.approve');
                Route::post('/token-requests/{id}/reject', [AdminTokenRequestController::class, 'reject'])->whereNumber('id')->name('token-requests.reject');
            });
            Route::middleware(['access:admin:usuarios'])->group(function (): void {
                Route::get('/users', [AdminUserController::class, 'index'])->name('users.index');
                Route::get('/users/{id}', [AdminUserController::class, 'show'])->whereNumber('id')->name('users.show');
                // Conceder o retirar accesos moviles desde la ficha del usuario,
                // sin esperar a que el interesado los solicite.
                // Conceder o retirar accesos moviles desde la ficha del usuario,
                // sin esperar a que el interesado los solicite.
                Route::post('/users/{id}/mobile-access/grant', [AdminUserController::class, 'grantAccess'])->whereNumber('id')->name('users.access.grant');
                Route::post('/users/{id}/mobile-access/revoke', [AdminUserController::class, 'revokeAccess'])->whereNumber('id')->name('users.access.revoke');
            });
        });

        // Actividad reciente del propio usuario. Reutiliza api_request_logs, la
        // auditoría que ya existe: no hay registro nuevo ni escritura extra.
        Route::middleware(['throttle:api-mobile', 'access:mobile'])->group(function (): void {
            Route::get('/activity', [ActivityController::class, 'index'])->name('activity.index');
        });

        // Centro de notificaciones de CodeRED Mobile. La ability `mobile` la
        // lleva todo token emitido por el login movil, asi que no hace falta un
        // permiso RBAC nuevo: cada quien lee lo suyo y nada mas. Los tokens
        // tecnicos (bridge React, n8n) no la tienen y quedan fuera.
        // Dispositivos que reciben push. Misma ability que el centro de
        // notificaciones: un dispositivo es de una persona, y un token tecnico
        // no tiene a quien avisar. El alta es un upsert por token y la baja
        // parte siempre de los dispositivos del propio usuario.
        // Solicitudes de acceso a modulos moviles. Solo la ability `mobile`:
        // pedir acceso es algo que cualquiera con la app puede hacer sobre si
        // mismo, y el permiso concreto se valida contra una lista blanca.
        // Pedir acceso para uno mismo lo puede hacer cualquier cliente oficial,
        // no solo Mobile: quien entra desde Desktop se encuentra igual sin
        // permisos y necesita la misma via. Basta la sesion —access:profile:read
        // no exige permiso adicional—, porque lo que se pide es sobre uno mismo
        // y el permiso concreto se valida contra una lista blanca.
        Route::middleware(['throttle:api-mobile', 'access:profile:read'])->prefix('permission-requests')->name('permission-requests.')->group(function (): void {
            Route::get('/', [PermissionRequestController::class, 'index'])->name('index');
            Route::post('/', [PermissionRequestController::class, 'store'])->name('store');
        });

        // Ruta anterior, conservada para las versiones de Mobile ya publicadas.
        Route::middleware(['throttle:api-mobile', 'access:mobile'])->prefix('mobile/permission-requests')->name('mobile.permission-requests.')->group(function (): void {
            Route::get('/', [PermissionRequestController::class, 'index'])->name('index');
            Route::post('/', [PermissionRequestController::class, 'store'])->name('store');
        });

        // Bandeja administrativa. La ability abre la seccion; el permiso RBAC
        // se vuelve a comprobar dentro en cada peticion.
        Route::middleware(['throttle:api-mobile', 'access:admin:accesos'])->prefix('admin/permission-requests')->name('admin.permission-requests.')->group(function (): void {
            Route::get('/', [AdminPermissionRequestController::class, 'index'])->name('index');
            Route::get('/{id}', [AdminPermissionRequestController::class, 'show'])->whereNumber('id')->name('show');
            Route::post('/{id}/approve', [AdminPermissionRequestController::class, 'approve'])->whereNumber('id')->name('approve');
            Route::post('/{id}/reject', [AdminPermissionRequestController::class, 'reject'])->whereNumber('id')->name('reject');
        });

        Route::middleware(['throttle:api-mobile', 'access:mobile'])->prefix('mobile/devices')->name('mobile.devices.')->group(function (): void {
            Route::post('/', [MobileDeviceController::class, 'store'])->name('store');
            Route::delete('/{id}', [MobileDeviceController::class, 'destroy'])->whereNumber('id')->name('destroy');
        });

        Route::middleware(['throttle:api-mobile', 'access:mobile'])->prefix('notifications')->name('notifications.')->group(function (): void {
            Route::get('/', [NotificationController::class, 'index'])->name('index');
            Route::get('/unread-count', [NotificationController::class, 'unreadCount'])->name('unread-count');
            Route::post('/read-all', [NotificationController::class, 'markAllAsRead'])->name('read-all');
            Route::post('/{id}/read', [NotificationController::class, 'markAsRead'])->name('read');
        });
        // Fuera del grupo de /dni/{dni} a proposito. Anidada dentro heredaba
        // ademas throttle:api-dni, api.audit:dni y access:dni:consultar, de modo
        // que exigia las DOS abilities -no solo dni:nombre, como documenta
        // docs/DNI_NAME_SEARCH.md-, escribia dos filas en api_request_logs
        // -una con identifier_hash nulo, porque ahi no hay parametro {dni}- y
        // consumia dos cubos de rate limit en cada peticion.
        Route::get('/dni/name-search', DniNameSearchController::class)
            ->middleware(['throttle:api-dni-name-search', 'api.audit:dni-name-search', 'api.delegate-user', 'access:dni:nombre'])
            ->name('dni.name-search');
        Route::middleware(['throttle:api-dni', 'api.audit:dni', 'api.delegate-user', 'access:dni:consultar'])->group(function (): void {
            Route::get('/dni/{dni}', DniApiController::class)->name('dni.show');
        });
        Route::get('/ruc/buscar', RucSearchApiController::class)->middleware(['throttle:ruc-search', 'api.audit:ruc', 'access:ruc:buscar'])->name('ruc.search');
        Route::get('/ruc/{ruc}/representantes', RucRepresentativeController::class)->middleware(['auth:sanctum', 'throttle:sunat-representatives', 'access:ruc:representantes'])->whereNumber('ruc')->name('ruc.representatives');
        Route::get('/ruc/{ruc}', RucApiController::class)->middleware(['throttle:ruc-lookup', 'api.audit:ruc', 'access:ruc:consultar'])->name('ruc.show');
        Route::middleware(['throttle:api', 'access:agencies:read'])->group(function (): void {
            Route::get('/agencies', [AgencyCatalogController::class, 'index'])->name('agencies.index');
            Route::get('/agencies/changes', AgencyChangesController::class)->name('agencies.changes');
            Route::get('/agencies/search', [AgenciesController::class, 'search'])->name('agencies.search');
            Route::get('/agencies/version', [AgenciesController::class, 'version'])->name('agencies.version');
            Route::get('/agencies/snapshot', [AgenciesController::class, 'snapshot'])->name('agencies.snapshot');
            Route::get('/catalog/metadata', CatalogMetadataController::class)->name('catalog.metadata');
            Route::get('/agencies/{code}', [AgencyCatalogController::class, 'show'])->name('agencies.show');
        });
        Route::post('/token-requests/rotation', TokenRotationRequestController::class)->middleware(['throttle:api'])->name('token-requests.rotation');
        Route::get('/me', MeController::class)->middleware(['throttle:api', 'access:profile:read'])->name('me');
        Route::get('/admin/shalom/delivery-records/export', [DeliveryRecordsExportController::class, 'csv'])
            ->middleware(['throttle:api'])
            ->name('admin.shalom.delivery-records.export.csv');
    });
});
