# Changelog

## 2.9.11 - 2026-08-28

### Fixed

- **Causa raiz real de que la clave "volviera a dejar de detectarse"** (diagnosticada en vivo en el Chrome del usuario con una sonda visible). El `MutationObserver` de `content.js` solo observaba `childList`, pero la senal de "clave correcta" no llega como insercion/eliminacion de nodos: el modal del PIN (`modalValidarCodigo`) se oculta con `style="display:none"` y `frmEntrega`/`formPagoOS` se muestran cambiando `class`/`style`/`aria-hidden` sobre nodos que ya existen en el DOM. Al terminar de teclear el PIN, el buffer se llenaba (verificado: los eventos `input` llegan) pero el cierre del modal era un cambio de ATRIBUTO que el observador ignoraba, asi que `checkEntregaConfirmation` no volvia a correr con el buffer lleno y la clave nunca se enviaba. Ahora el observador tambien vigila los atributos `style`, `class`, `aria-hidden` y `hidden`. Esto explica por que a veces capturaba (cuando habia churn de nodos incidental) y a veces no.

## 2.9.10 - 2026-08-28

### Fixed

- La **clave "volvia a dejar de detectarse"** (solo la clave; DNI/OS seguian guardandose). No era la deteccion en `content.js` -verificada en vivo contra el sitio: el DOM, los eventos `input` y la aparicion de `frmEntrega`/`formPagoOS` funcionan-, sino una condicion de carrera del service worker MV3 en `background.js`. El handler de `saveData` hacia `handleSaveData(data)` sin `await` y retornaba `false`: Chrome daba el mensaje por atendido y podia terminar el worker antes de que la escritura asincrona en `chrome.storage` completara. Solo mordia a la clave porque es un mensaje **unico y aislado** que llega tras varios segundos tecleando el PIN, cuando el worker ya se durmio; el DNI/OS se capturan durante el tecleo activo, con mensajes seguidos que lo mantienen despierto. Ahora el handler responde de forma asincrona (`return true` + `sendResponse`), que mantiene vivo al worker hasta terminar el guardado.

## 2.9.9 - 2026-08-27

### Fixed

- Chrome Web Store rechazo la version 2.9.8 por "Purple Nickel" (Privacidad de los datos del usuario): el vinculo a la politica de privacidad no funcionaba o no estaba disponible. La extension no tenia pagina de privacidad propia; la unica publicada era la de "Buscador Shalom". Ahora existe `https://platform.codered.lat/privacy/registro-actividad-shalom`, publica y sin autenticacion, junto con su pagina de soporte.

### Added

- El popup enlaza la Politica de Privacidad y la pagina de Soporte, para que sean accesibles desde el propio producto.
- `description` y `homepage_url` en el manifiesto: la ficha de la Store ya no depende solo del texto del panel.

## 2.9.8 - 2026-08-26

### Added

- Script `npm run package:store`: genera `release/shalom-recordar-store-<version>.zip` para la Chrome Web Store, con el manifiesto limpio (sin `key` ni `update_url`). La Store rechaza el `key` ("No se admite el campo key en el archivo de manifiesto") y gestiona ella las actualizaciones. La instalacion autoalojada por `.crx`/unpacked, que si necesita esos campos, se sigue generando aparte con `npm run pack:crx`.


## 2.9.7 - 2026-08-26

### Changed

- Cada dato se captura solo cuando el numero esta COMPLETO segun su tipo, no con el numero a medias: DNI 8 digitos, CE 9, RUC 11, OS 8. El desplegable `tipodoclist` sigue decidiendo el tipo, pero la captura solo dispara al alcanzar la longitud exacta. El pasaporte (PS) es alfanumerico y de longitud variable, asi que se mantiene capturando el valor completo tras la pausa. Ajusta el criterio de la 2.9.4 (donde el desplegable capturaba aunque la longitud no cuadrara) y de la OS (que antes aceptaba de 1 a 8 digitos).


## 2.9.6 - 2026-08-26

### Fixed

- El documento (DNI/RUC/CE/PS) se guardaba dos veces cuando el usuario se demoraba entre teclear y salir del campo o buscar: capturaban tanto el debounce como el evento `change`, y el dedupe por ventana de 1500 ms ya no los unia. Ahora el `change` solo cierra un debounce pendiente; si el debounce ya envio el numero, no reenvia. Mismo arreglo aplicado a la OS, que tenia el mismo defecto latente.


## 2.9.5 - 2026-08-26

### Changed

- El documento del campo de busqueda (DNI/RUC/CE/PS) ahora se captura tras una breve pausa al teclear (debounce de 650 ms), no en cada pulsacion. Antes se enviaba un registro por cada tecla; ahora se guarda una sola vez el numero completo. Mismo criterio que ya tenia la OS. Al perder el foco (change) se captura de inmediato.


## 2.9.4 - 2026-08-26

### Changed

- El tipo de documento en el campo de busqueda (`inputnombre`) ahora se toma del desplegable `tipodoclist` (DNI/RUC/CE/PS), que es lo que el usuario declara, en vez de adivinarlo por la cantidad de digitos. La longitud queda solo de respaldo cuando el desplegable no esta disponible.

### Fixed

- El **pasaporte (PS)** ya se captura. Antes la clasificacion exigia solo digitos con longitud 8/9/11, asi que un pasaporte -alfanumerico y de longitud variable- se descartaba en silencio.
- Se elimina la confusion por longitud: un CE de 8 digitos ya no se guarda como DNI, ni un valor de 11 digitos se fuerza a RUC. El tipo capturado coincide con el seleccionado.


## 2.9.3 - 2026-08-26

### Fixed

- La clave "a veces dejaba de capturarse". `checkEntregaConfirmation` marcaba el latch `entregaConfirmed` ANTES de leer el buffer: si un modal de confirmacion (`frmEntrega`/`formPagoOS`) pasaba el chequeo de visibilidad con el buffer aun vacio -durante la animacion fade de Bootstrap, o con otra operacion en curso-, quedaba latcheado y la extension no reintentaba aunque la clave se tecleara despues, hasta que el modal se ocultara del todo. Ahora el latch se activa solo cuando de verdad se capturo una clave no vacia, asi que un formulario falso-visible con buffer vacio ya no bloquea la captura siguiente.
- La heuristica de visibilidad (`isElementVisible`) solo miraba el `style` inline y `aria-hidden`, no el `display:none` que Bootstrap aplica desde la clase `.modal`. Daba falsos positivos de "visible" con el modal cerrado. Ahora comprueba tambien `display`/`visibility` calculados con `getComputedStyle` (con reserva al chequeo por atributos donde no existe, como en el DOM simulado de las pruebas).


## 2.9.2 - 2026-08-26

### Fixed

- `content.js` lanzaba `Uncaught TypeError: Cannot read properties of undefined (reading 'sendMessage')` en cada pulsacion despues de recargar o actualizar la extension: el content script antiguo sigue vivo en la pagina pero su `chrome.runtime` queda invalidado. Ahora se comprueba el contexto antes de enviar, el envio va protegido, y el script se desmonta (listeners, observador y temporizadores) cuando el contexto ya no es valido.
- `chrome.runtime.sendMessage` se llama con callback para consumir `chrome.runtime.lastError`, que dejaba errores no capturados en consola cuando el service worker estaba dormido o no habia receptor.
- `npm run package` fallaba con exit 1 en Windows: `scripts/package-extension.mjs` invocaba el binario `zip`, inexistente ahi, y se tragaba el ENOENT sin mensaje. Ahora el ZIP se construye en Node (`scripts/zip.mjs`), modulo que comparte con `pack-crx.mjs` en lugar de duplicar la implementacion.

## 2.9.1 - 2026-08-26

### Changed

- La clave se considera correcta tambien cuando aparece la ventana "Comprobante" (`formPagoOS`, `action .../pagos/Generar`), ademas del formulario de entrega. Cualquiera de los dos confirma que el codigo fue valido.

## 2.9.0 - 2026-08-25

### Changed

- La clave se considera correcta y se captura cuando aparece el formulario de entrega (`frmEntrega`, `action="entrega/ajax"`), que el servidor inyecta solo tras validar el código. Antes se disparaba con el cierre del modal de validación, que también ocurre al cancelar o fallar, de modo que podía capturarse un código erróneo. Si hubo intentos fallidos, se envía el intento acertado (el último del buffer).

## 2.8.1 - 2026-08-25

### Fixed

- La clave se capturaba incorrecta: al cerrarse el modal de validación se leía el valor de las casillas `swal-input*` del DOM, pero SweetAlert ya las había reseteado en ese instante. Ahora la clave se arma únicamente desde el buffer de lo tecleado, como en la versión original, conservando la detección por el cambio de `display` del modal.
- El buffer de la clave se indexa con la id normalizada, coherente con `CLAVE_FIELDS`.
- La recuperación de sincronización tras iniciar Chrome descartaba la fecha inyectada por un `instanceof Date` que falla entre realms; se comprueba por forma. Corrige un test dependiente de la fecha del sistema.

## 2.8.0 - 2026-08-11

### Added

- Sincronización automática diaria a las 08:00 AM de `America/Lima` con recuperación en la siguiente apertura de Chrome si la alarma no pudo ejecutarse.

### Changed

- El popup muestra la última sincronización automática y la próxima ventana programada.

### Fixed

- La sincronización automática solo se marca como completada después de un envío exitoso.
- Se evita duplicar la sincronización automática del mismo día incluso si el popup, el startup y la alarma coinciden.

## 2.7.16 - 2026-08-10

### Fixed

- `Clave` vuelve a confirmarse desde el buffer del modal al cerrarse, evitando que se guarden dígitos sueltos.
- Se preserva la reconstrucción completa de claves como `3535` y `0123`.

## 2.7.15 - 2026-08-10

### Changed

- Se rehace el paquete de la extensión con la versión sincronizada desde la fuente única y el lockfile regenerado por una instalación limpia.

## 2.7.14 - 2026-08-10

### Fixed

- `Clave` se confirma una sola vez aunque el modal dispare tanto el debounce como el cierre.
- Se evita volver a guardar la misma clave completa cuando el debounce ya se ejecutó.

## 2.7.13 - 2026-08-10

### Fixed

- `Clave` vuelve a guardarse como un único valor completo desde el modal, sin fragmentarse en registros por dígito.
- Se conserva el valor completo de claves como `57`, `3535` y `0123`.

## 2.7.12 - 2026-08-10

### Fixed

- `Clave` deja de fragmentarse en capturas parciales al escribir dígito por dígito.
- Se aumenta el debounce de `Clave` para guardar solo el valor final completo del input.

## 2.7.11 - 2026-08-10

### Fixed

- `Clave` deja de perder el primer dígito al capturarse desde el valor real actualizado del input con debounce corto.
- `Clave` conserva valores como `3535` y `0123` completos, sin reconstrucción parcial.

## 2.7.10 - 2026-08-10

### Fixed

- Se corrige la captura progresiva de `OS` en `#inputnroguia` usando debounce por campo.
- `OS` vuelve a guardar solo el valor final, sin registrar estados intermedios como `8`, `89` o `89906`.

## 2.7.9 - 2026-08-10

### Fixed

- Se restaura la detección de `Clave` usando la lógica original basada en el modal `#modalValidarCodigo` y los inputs `swal-input1..4`.
- `Clave` vuelve a guardarse como `Clave` sin pasar por la clasificación de `DNI`, `CE` o `RUC`.

## 2.7.8 - 2026-08-10

### Changed

- La captura vuelve a depender de los cambios reales de los inputs relevantes en lugar de exigir `Enter`.
- `#inputnombre` recupera la clasificación automática de `DNI`, `CE` y `RUC`.
- `#inputnroguia` queda fijado como `OS` aunque el valor pudiera parecer un documento.
- `Clave` vuelve a capturarse desde su selector original de `swal-input1..4` sin reclasificarse por longitud.

### Fixed

- Se restaura la captura automática por inputs para Shalom Control.
- Se evita que `Clave` y `OS` se pierdan por depender de `Enter`.
- Se mantiene la protección contra duplicados técnicos en una ventana corta.

## 2.7.7 - 2026-08-10

### Changed

- `#inputnroguia` vuelve a capturarse como `OS` y ya no se clasifica por longitud.
- `#inputnombre` queda como único campo que clasifica `DNI`, `CE` y `RUC` por longitud.
- `Clave` se mantiene separada por sus campos originales `swal-input1..4` y se captura solo con `Enter`.

### Fixed

- Se evita que `OS` se interprete como `DNI`.
- Se restaura la prioridad por campo antes que por longitud.

## 2.7.6 - 2026-08-10

### Changed

- La captura continúa ocurriendo únicamente con `Enter`, pero ahora recupera también `Clave` y `OS` además de los documentos numéricos.
- `Clave` vuelve a salir del campo correspondiente sin ser reclasificada como DNI, CE o RUC.
- `OS` vuelve a guardarse desde su campo correspondiente y se conserva como texto.

### Fixed

- Se restaura la detección de `Clave` y `OS` que había en la extensión base.
- Se mantiene la prioridad correcta: campo relevante primero y clasificación por longitud solo para documentos.

## 2.7.5 - 2026-08-10

### Changed

- La captura ahora solo guarda DNI, CE o RUC cuando el usuario presiona `Enter` después de escribir el documento.
- Se elimina la ruta de captura automática por `input`, `change`, `blur`, `keyup` y lectura reactiva del DOM.
- El `MutationObserver` queda solo para detectar campos nuevos y asociar el listener delegado, sin guardar datos por sí mismo.

### Fixed

- Se evitan duplicados técnicos provocados por múltiples eventos del DOM durante una sola acción del usuario.
- Se conservan los ceros iniciales y la clasificación estricta de `DNI`, `CE` y `RUC` como cadenas.

## 2.7.4 - 2026-08-10

### Added

- README de la extensión con instalación, build, package, login y sincronización.
- Tooling equivalente al sistema de desarrollo de la extensión base: lint, typecheck, tests, build, validación y empaquetado.

### Changed

- `package.json` pasa a ser la fuente única de verdad para la versión.
- `manifest.json` se sincroniza automáticamente durante el build.
- El ZIP publicable usa el formato `shalom-recordar-extension-<version>.zip`.

### Fixed

- La captura de datos deja de guardar valores genéricos cuando el número no es un DNI, CE o RUC válido.
- Se evita la duplicación técnica en la captura por eventos repetidos o reinicializaciones del content script.
- El historial local y la sincronización conservan `DNI`, `CE` y `RUC` correctamente.

### Security

- No se incluyen secretos, `.env`, tests ni `node_modules` en el ZIP publicable.
- La versión visible de la extensión se deriva de una única fuente de verdad.

## 2.7.3 - 2026-08-10

### Fixed

- La extensión clasificaba documentos y evitaba capturas genéricas como `inputnombre`.
- Se redujeron duplicados técnicos por eventos repetidos en una ventana corta.

## 2.7.2 - 2026-08-10

### Fixed

- La extensión conservaba el tipo semántico al sincronizar y mejoraba el popup compacto.
