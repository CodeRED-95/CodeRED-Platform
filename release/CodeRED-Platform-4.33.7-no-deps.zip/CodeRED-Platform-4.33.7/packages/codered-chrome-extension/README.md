# Buscador Shalom Control

## Versión

Fuente única de verdad: `package.json` (`2.9.0`).

Extension Chrome Manifest V3 para inyectar un buscador de agencias dentro de Shalom Control y consultar agencias usando CodeRED Platform como unica fuente oficial.

La extension no realiza scraping, no consume GitHub Gist y no usa JSON estatico como fuente principal. Despues de la primera sincronizacion correcta, la busqueda se ejecuta localmente desde `chrome.storage.local` y sigue funcionando sin conexión con la ultima cache valida.

## Versión

La version visible de la extension es la de `package.json` (fuente unica de verdad). El build sincroniza automaticamente `src/shared/version.ts`, `manifest.json`, el popup y las pruebas con esa misma version.

### Popup compacto

El popup fue reconstruido desde cero como una sola columna de 360 px, tema oscuro CodeRED y altura dependiente del contenido. No contiene buscador de agencias, listado, tarjetas de resultados, paneles informativos extensos, datos tecnicos ni scroll interno.

Datos mostrados:

- Logo y nombre `Buscador Shalom`.
- Version de la extension.
- Estado del token.
- Token enmascarado cuando existe.
- Ultima sincronizacion.
- Agencias disponibles.
- Estado corto de conexion.
- Estado de sincronizacion automatica.

Acciones disponibles:

- `Solicitar token`: abre `https://platform.codered.lat/solicitar-token`.
- `Configurar token`: ejecuta `chrome.runtime.openOptionsPage()`.
- `Probar conexión`: disponible solo con token y llama a `API_TEST_CONNECTION`.
- `Solicitar otro token`: enlace discreto disponible solo con token.

Sin token, el popup muestra `Token no configurado`, `Sin sincronizar`, `0` agencias y estado `Desconectado`. Si no puede leer el estado local, mantiene disponibles `Solicitar token` y `Configurar token`.

## Desarrollo

PowerShell:

```powershell
cd E:\Documentos\GitHub\CodeRED-Platform\packages\codered-chrome-extension
Remove-Item -Recurse -Force node_modules -ErrorAction SilentlyContinue
Remove-Item -Force package-lock.json -ErrorAction SilentlyContinue
npm install
npm run lint
npm run typecheck
npm test
npm run build:extension
```

Linux o Docker:

```bash
cd /var/www/html/packages/codered-chrome-extension
rm -rf node_modules package-lock.json
npm install
npm run lint
npm run typecheck
npm test
npm run build:extension
```

## API consumida

- `GET /api/v1/extension/chrome/config`: configuracion publica sin secretos.
- `GET /api/v1/me`: validacion del token.
- `GET /api/v1/catalog/metadata`: revision del catalogo y cursor.
- `GET /api/v1/agencies`: sincronizacion completa paginada.
- `GET /api/v1/agencies/changes`: sincronizacion incremental cuando el cursor sea valido.
- `GET /api/v1/extension/chrome/block-rules`: reglas de bloqueo horario publicadas desde el panel. No exige un scope concreto, basta un token valido, porque la configuracion es global.

Scopes requeridos: `agencias:consultar`, `agencies:read`, `agencies:map`.

## Carga manual en Chrome

1. Ejecutar `npm run build:extension`.
2. Abrir `chrome://extensions`.
3. Activar Modo de desarrollador.
4. Elegir Cargar extension sin empaquetar.
5. Seleccionar `packages/codered-chrome-extension/dist`.
6. Para aplicar cambios posteriores, volver a `chrome://extensions` y pulsar Recargar en la tarjeta de la extension descomprimida.
7. Recargar la pestaña abierta de Shalom Control para que Chrome reinstale el content script en la pagina.

## Build de extension

El build separa tres contextos:

- `popup.html` y `options.html` se compilan como paginas de extension con modulos ES y rutas relativas `./assets/...`.
- `background.js` se compila como service worker modulo y el manifest declara `type: module`.
- `content.js` se compila aparte como IIFE autocontenido, sin `import`, `export`, `import(...)` ni `require(...)`, porque Chrome lo ejecuta como content script clasico.

Usar `npm run build:extension` para compilar y validar `dist`. El validador revisa manifest, archivos declarados, sintaxis de `content.js`, ausencia de imports en el content script, ausencia de rutas absolutas `/assets` en HTML y ausencia de preloads a `modulepreload-polyfill`.

## ZIP publicable

```bash
npm run package
```

El ZIP queda en `packages/codered-chrome-extension/release/codered-chrome-extension-<version>.zip` y se genera con la version real leida desde `package.json`.

## Cache y sincronizacion

La extension conserva la ultima cache funcional ante errores de red, 401, 403 o respuestas vacias inesperadas. El service worker programa `chrome.alarms` cada 24 horas y evita sincronizaciones paralelas. Eliminar el token no borra las agencias cacheadas, pero bloquea nuevas sincronizaciones hasta configurar otro token.

## Storage canonico

La extension usa estas claves canonicas en `chrome.storage.local`:

- `codered_api_token`: token privado, nunca se muestra completo en el popup.
- `codered_token_metadata`: metadata visible, incluido `tokenMasked`.
- `codered_agency_catalog`: catalogo local de agencias.
- `codered_sync_metadata`: revision, cursor, ultima sincronizacion, estado y mensaje.
- `codered_catalog_version`, `codered_last_sync_at`, `codered_last_sync_status`: compatibilidad de metadata sincronizada.

Al iniciar, el storage migra claves antiguas como `auth`, `token`, `apiToken`, `coderedToken`, `accessToken`, `platformToken` y `catalogToken` hacia la clave canonica sin imprimir el secreto.

## CORS

Configurar `API_ALLOWED_ORIGINS` con el origen de la extension si se restringe el entorno productivo. CodeRED expone `ETag` y `Last-Modified` para optimizar sincronizaciones.

## Solucion de problemas

- 401: el token no es valido o vencio.
- 403: el token no tiene permisos para consultar agencias.
- Sin conexion: se usan datos guardados.
- Cero agencias: la sincronizacion se considera invalida y se conserva la cache anterior.
- Popup con `No fue posible leer el estado local`: revisar permisos `storage`, service worker en `chrome://extensions` y recargar la extension.
- Content script no aparece: recargar la pestaña de Shalom Control despues de recargar la extension.

## Bloqueo horario

El horario de bloqueo no vive en el codigo: lo administra un super-admin en CodeRED Platform, en `Configuracion > Bloqueo extension` (`/admin/settings/bloqueo-extension`).

Ademas es **opt-in por token**: solo se aplica en las instalaciones cuyo token lleva la ability `extension:blocking`, que se concede o retira token a token desde `/admin/api-tokens`. Un token sin ella recibe 403 en el endpoint de reglas, no guarda ninguna, no muestra la tarjeta de control en el popup y no bloquea nada.

Cada regla define:

- **Destinos**: uno o varios, uno por linea, cada uno con su propia ruta. Se admite pegar la URL completa (`https://sysprovincia2.shalomcontrol.com/ordenservicio/listar`), solo el dominio (hereda la ruta por defecto de la regla) o comodines (`*.shalomcontrol.com`, `/ordenservicio/*`). La regla aplica si coincide cualquiera de sus destinos, dominio y ruta a la vez. Solo se admiten hosts de `shalomcontrol.com`, que es el unico dominio con `host_permissions`.
- **Modo**: `horario permitido` (fuera de las ventanas se bloquea, el comportamiento historico) u `horario bloqueado` (solo se bloquea dentro de las ventanas).
- **Ventanas por dia**: lunes a sabado 08:00-20:05 y domingo 08:00-17:05 es un caso valido. Un dia sin ventana queda bloqueado el dia entero en modo permitido.
- **Zona horaria**: `America/Lima` por defecto; los limites se calculan con `Intl`, no con un desfase fijo.

El service worker descarga las reglas al instalar la extension, al arrancar el navegador, cada 30 minutos y en cada sincronizacion manual. Guarda la ultima copia en `chrome.storage.local` (`codered_block_rules`): si la red falla se conserva el bloqueo anterior. Si nunca se sincronizo nada —o el token no tiene la ability y el endpoint responde 403— no hay reglas y no se bloquea nada: el control horario es opt-in, no hay horario de respaldo escrito en el codigo.

El bloqueo manual y el desbloqueo forzoso del popup no cambian: el desbloqueo forzoso sigue caducando al llegar el proximo cambio de horario de la regla afectada.

## Dominios compatibles

### Seleccion de destino segun la pagina

- `/ordenservicio/listar` (sitio clasico): `<select id*="osProDestino">` + Chosen, gestionado por `agency-selector.ts`. Sin cambios.
- `/service-order/items` (SPA Vue de sysnewos): combobox propio, gestionado por `destination-combobox.ts`. El valor real es el ID de la agencia (`li[data-key]`, que coincide con nuestro `external_id`); el commit se dispara con `mousedown` y el filtro del sitio solo busca por departamento, provincia o distrito con `startsWith`, nunca por el nombre de la agencia. El canal se lee de los radios `input[name="transport-type"]`.
- `/listaordenservicio` y `/service-order`: solo consulta, sin seleccion.

El content script se carga en `https://*.shalomcontrol.com/*` (todo el dominio, para poder aplicar el bloqueo horario en cualquier ruta que configure el panel). El **buscador** sigue inyectandose solo en las rutas soportadas, que decide `isSupportedShalomPage()` en tiempo de ejecucion:

- `/listaordenservicio`
- `/service-order`
- `/service-order/items`
- `/ordenservicio/listar`

`https://platform.codered.lat/*` permanece en `host_permissions` para que el service worker sincronice con CodeRED Platform, pero no esta en `content_scripts.matches` y no recibe el buscador.

`https://platform.codered.host/*` sigue declarado en `host_permissions` **solo por compatibilidad temporal** con la migracion de dominio `codered.host` -> `codered.lat`: las instalaciones ya publicadas en la Chrome Web Store pueden tener guardado el dominio anterior y perderian la sincronizacion sin este permiso. Eliminelo cuando `codered.lat` este validado al 100% y se publique una nueva version de la extension. El dominio por defecto vive en un unico sitio, `src/models/configuration.ts` (`DEFAULT_API_BASE_URL`), sobrescribible en build time con `VITE_CODERED_API_BASE_URL`.

## Integracion con Shalom Control

La extension se inyecta automaticamente en `shalomcontrol.com`, cualquier `*.shalomcontrol.com`, `shalom.pe` y cualquier `*.shalom.pe`. `sysprovincia2` y `syslima` son ejemplos, no una lista cerrada.

El content script intenta inyectar inmediatamente al iniciar y luego observa cambios SPA con `MutationObserver` y debounce. Busca encabezados compatibles como `.mdl-layout__header-row`, `header .mdl-layout__header-row`, `.mdl-layout__header`, `header`, `[role="banner"]`, `.navbar`, `.topbar` y `.header`; inyecta una sola vez `#mi-buscador-contenedor` y lo reinyecta si Shalom reemplaza el encabezado.

Detecta Terrestre/Aereo mediante `title`, texto visible normalizado, `onclick`, clases activas y `aria-selected`. El canal interno se normaliza a `TERRESTRE` o `AEREO`.

En `https://*.shalomcontrol.com/listaordenservicio` la deteccion del canal puede quedar neutral por ausencia de evidencia suficiente. En ese caso el buscador no bloquea la UI, muestra `Canal no identificado. Buscando en todas las agencias.` y busca en todas las agencias publicas disponibles.

Para seleccionar destino localiza `select[id*="osProDestino"]`, prioriza selectores visibles y habilitados, rechaza multiples candidatos activos, asigna el valor real del `select`, dispara `input` y `change`, y actualiza el DOM de Chosen cuando existe. Si una agencia de CodeRED no esta en el selector actual, no cambia el formulario.

El content script no recibe el token. Usa mensajes `CATALOG_GET`, `CATALOG_STATUS` y `CATALOG_SYNC` contra el service worker, que es el unico componente que llama a CodeRED Platform con Bearer token.

## Diagnostico del content script

En la consola de la pagina Shalom deben aparecer logs con prefijo `[Shalom Pro]`, por ejemplo `Content script iniciado`, `Dominio permitido`, `Target encontrado con selector: ...` y `Buscador inyectado`. Para comprobar la inyeccion desde DevTools ejecutar:

```js
document.getElementById('mi-buscador-contenedor')
```

Si devuelve `null`, revisar la consola de la pagina. Si hay errores del service worker, abrir `chrome://extensions`, buscar la extension y entrar a Inspeccionar vistas/service worker.

## Catalogo vacio

El buscador se muestra aunque `chrome.storage.local` no tenga agencias. En ese estado, al escribir muestra: `No hay agencias sincronizadas. Abre la configuracion y pulsa Sincronizar ahora`. Abrir Opciones de la extension, guardar un token valido si falta, pulsar Sincronizar ahora y recargar o volver a escribir en el buscador; el content script escucha cambios de `chrome.storage.local` y recarga el catalogo sin reinstalar la extension.

## Dependencias de pruebas

La version 2.3.3 fija `chai` en `5.2.1` mediante `overrides` para evitar la resolucion defectuosa `chai@5.3.3 -> pathval@^2.1.0`, ya que `pathval` solo publica hasta `2.0.1`. Vitest permanece en la linea 3.2.x y sigue siendo el runner de pruebas compatible con Vite 6.
