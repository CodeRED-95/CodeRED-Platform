import type { Config } from '../config/Config.js';
import { Logger } from '../logging/Logger.js';
import type { AgentStorage } from '../storage/AgentStorage.js';
import type { StoredIntegration } from '../storage/types.js';
import type { LocalPairRequest, PlatformPairRequest } from './PairRequests.js';
import { CodeREDClient } from './CodeREDClient.js';
import { DiscoveryService } from './DiscoveryService.js';
import { HeartbeatService } from './HeartbeatService.js';

export type PairingInput = LocalPairRequest;

interface PairingResponse {
  success?: boolean;
  data?: {
    integration_uuid?: string;
    shared_secret?: string;
    protocol_version?: string;
    paired_at?: string;
    discovery_url?: string;
    heartbeat_url?: string;
    challenge_url?: string;
  };
}

export class PairingService {
  public constructor(
    private config: Config,
    private storage: AgentStorage,
    private client: CodeREDClient,
    private discovery: DiscoveryService,
    private heartbeat: HeartbeatService,
    private logger = new Logger(config.logLevel),
  ) {}

  public async pair(input: PairingInput): Promise<Record<string, unknown>> {
    const pairCode = input.pair_code?.trim();

    if (!pairCode) {
      throw new Error('pairCode is required');
    }

    const identity = await this.storage.ensureIdentity(this.config.name);
    const instanceUuid = identity.instance_uuid;
    const instanceName = input.instance_name || this.config.name;
    const instanceUrl = input.instance_url || this.config.publicUrl;
    const environment = input.environment || this.config.environment;

    this.logger.info('identity.instance_uuid.loaded', { instance_uuid: instanceUuid });
    this.logger.info('pair.request', {
      instance_uuid: instanceUuid,
      instance_name: instanceName,
      instance_url: instanceUrl,
      environment,
      pair_code_present: true,
    });
    this.logger.info('pairing.started', { instanceUuid });

    const platformPayload: PlatformPairRequest = {
      pair_code: pairCode,
      instance_uuid: instanceUuid,
      instance_name: instanceName,
      instance_url: instanceUrl,
      environment,
      version: input.version,
      agent_version: '1.0.0',
    };

    const response = await this.client.pair(platformPayload) as PairingResponse;
    const data = response.data;

    if (!data?.integration_uuid || !data.shared_secret) {
      this.logger.error('pairing.failed', { reason: 'invalid_platform_response' });
      throw new Error('Invalid pairing response');
    }

    const pairedAt = data.paired_at || new Date().toISOString();
    const integration: StoredIntegration = {
      instance_uuid: instanceUuid,
      integration_uuid: data.integration_uuid,
      shared_secret: data.shared_secret,
      protocol_version: data.protocol_version || '1.0',
      paired_at: pairedAt,
      platform_url: this.config.platformUrl,
      agent_name: this.config.name,
      instance_name: instanceName,
      instance_url: instanceUrl,
      environment,
      secret_version: 1,
      discovery_url: data.discovery_url || '/api/v1/integrations/n8n/discovery',
      heartbeat_url: data.heartbeat_url || '/api/v1/integrations/n8n/heartbeat',
      challenge_url: data.challenge_url || '/api/v1/integrations/n8n/challenge',
    };

    try {
      await this.storage.saveIntegration(integration);
      this.client.setPairing(integration);
      this.logger.info('identity.saved', { paired: true, integration_uuid: integration.integration_uuid, instanceUuid: integration.instance_uuid });
      this.logger.info('pairing.persisted', { instanceId: integration.integration_uuid });
    } catch (error) {
      this.client.clearPairing();
      this.logger.error('pairing.persistence_failed', { error: error instanceof Error ? error.message : 'Unknown persistence error' });
      throw error;
    }

    this.logger.info('pairing.completed', { instanceId: data.integration_uuid });

    return {
      success: true,
      paired: this.client.isPaired(),
      instanceId: data.integration_uuid,
      integration_uuid: data.integration_uuid,
      instance_uuid: instanceUuid,
      protocolVersion: integration.protocol_version,
      pairedAt,
    };
  }
}
